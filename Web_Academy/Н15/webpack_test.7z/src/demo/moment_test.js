import moment from "moment";

// https://momentjs.com/

console.log(moment().format("MMMM Do YYYY, h:mm:ss a")); // July 15th 2020, 6:41:46 pm
console.log(moment().format("dddd")); // Wednesday
console.log(moment().format("MMM Do YY")); // Jul 15th 20
console.log(moment().format("YYYY [escaped] YYYY")); // 2020 escaped 2020
console.log(moment().format()); // 2020-07-15T18:42:18+03:00

console.log(moment("20111031", "YYYYMMDD").fromNow()); // 9 years ago
console.log(moment("20120620", "YYYYMMDD").fromNow()); // 8 years ago
console.log(moment().startOf("day").fromNow()); // 19 hours ago
console.log(moment().endOf("day").fromNow()); // in 5 hours
console.log(moment().startOf("hour").fromNow()); // 42 minutes ago
