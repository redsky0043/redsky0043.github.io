import faker from "faker";
// https://www.npmjs.com/package/faker
const generateUsers = (count = 5) => {
  let users = [];
  for (let i = 0; i < count; i++) {
    users.push({
      name: faker.name.findName(),
      email: faker.internet.email(),
      card: faker.helpers.createCard(),
    });
  }

  return users;
};

console.log(generateUsers());
