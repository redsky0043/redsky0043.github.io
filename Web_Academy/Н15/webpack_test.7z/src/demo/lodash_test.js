import _ from "lodash";
// https://lodash.com/docs/4.17.15

const list = [1, 2, 3, 4, 5, 6];

// document.body.innerHTML = _.map(list, (item) => item);

// ------------------

// const obj = { a: 1, b: 2, c: 3 };

// console.log(_.map(obj, (item) => console.log(item)));

// ------------------

// const a = { a: 1 };
// const b = { a: 1 };
// console.log(_.isEqual(a, b));

// ----------------------------

// const a = [1, [2, [3, [4]], 5]];

// const b = _.flatten(a);
// console.log(a);
// console.log(b);

// ----------------------------

// const a = [1, [2, [3, [4]], 5]];

// const b = _.flattenDeep(a);
// console.log(a);
// console.log(b);

// ----------------------------

// console.log(_.uniq([2, 1, 2]));

// ---------------------------------

const objects = [{ a: 1 }, { b: 2 }];

const deep = _.cloneDeep(objects);
console.log(deep[0] === objects[0]);
